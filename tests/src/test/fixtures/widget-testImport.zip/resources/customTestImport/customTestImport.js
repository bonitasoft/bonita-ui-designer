angular.module('org.bonitasoft.pagebuilder.widgets')
  .directive('customTestImport', function() {
    return {
      controllerAs: 'ctrl',
      controller: function WidgettestImportController($scope) {
    this.sayClicked = function() {
        $scope.properties.value = 'clicked';
    };
},
      template: '<div ng-click="ctrl.sayClicked()">Enter your template here, using {{ properties.value }}</div>'
    };
  });
